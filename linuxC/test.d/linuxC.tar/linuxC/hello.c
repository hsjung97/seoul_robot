#include <stdio.h>

int main(int arg, int **argv)
{
	printf("Hello World\n");
	return 0;
}
